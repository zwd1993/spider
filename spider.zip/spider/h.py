text = """

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <title>兖州市量子科技有限责任公司与孟凡英专利权权属纠纷二审民事判决书 &#8211; 裁判文书 | OpenLaw</title>

    <link rel="stylesheet" href="/css/popover.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/css/default.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/css/dropdown.css" type="text/css" media="all" />
    <link rel="stylesheet" href="/css/annotator.min.css" type="text/css" media="all" />
    
    




	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="兖州市量子科技有限责任公司与孟凡英专利权权属纠纷二审民事判决书"/>
	<meta name="description" content="兖州市量子科技有限责任公司与孟凡英专利权权属纠纷二审民事判决书分析,讨论,打印,下载"/>
	<link rel="shortcut icon" type="image/png" href="http://static.07law.com/common/images/logo/openlaw/blue/16.png" />
	<link rel="apple-touch-icon" href="/images/logo/apple/white-blue.jpg" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	
	<link rel="stylesheet" id="ht-voting-frontend-style-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/plugins/ht-voting/css/ht-voting-frontend-style.css" type="text/css" media="all" />
	<link rel="stylesheet" id="contact-form-7-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/plugins/contact-form-7/includes/css/styles.css" type="text/css" media="all" />
	<link rel="stylesheet" id="bbp-default-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/css/bbpress.css" type="text/css" media="screen" />
	<link rel="stylesheet" id="ht-social-widget-display-style-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/plugins/heroic-social-widget/css/ht-social-widget-display-style.css" type="text/css" media="all" />
	<link rel="stylesheet" id="font-awesome-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/plugins/heroic-social-widget/css/font-awesome.min.css" type="text/css" media="all" />
	<link rel="stylesheet" id="theme-style-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" id="ht-kb-css" href="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/css/ht-kb.css" type="text/css" media="all" />
	<!-- 
	<link rel="stylesheet" id="ht-google-font-css" href="http://static.openlaw.cn/theme/helpguru/refs/g0.css" type="text/css" media="all" />
	 -->
	<link rel='stylesheet' id='ht-google-font-css'  href='http://fonts.googleapis.com/css?family=Open+Sans:400,400italic,700,700italic|Nunito:400,300,700' type='text/css' media='all' />
	<script type="text/javascript" src="http://static.openlaw.cn/theme/helpguru/refs/jquery.js"></script>
	<script type="text/javascript" src="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/inc/ht-core/js/jquery-picture-min.js"></script>
	<!--[if lt IE 9]><script src="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/inc/ht-core/js/html5.js"></script><![endif]-->
	<!--[if (gte IE 6)&(lte IE 8)]><script src="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/inc/ht-core/js/selectivizr-min.js"></script><![endif]-->
	<link rel="stylesheet" href="/css/morris.css" type="text/css" media="all" />
	<link rel="stylesheet" href="/css/openlaw.css" type="text/css" media="all" />
	<link rel="stylesheet" href="/user/css/style.css" />
	<style type="text/css">
	a,a:visited {
		color: #32a3cb;
	}
	a:hover {
		color: #32a3cb;
	}
	#site-header {
		background: #2e97bd;
	}
	@media screen and (max-width: 720px) {
		#nav-primary-menu {
			background: #2e97bd;
		}
	}
	#site-header,#site-header a,#site-header a:visited,#site-header a:hover {
		color: #ffffff;
	}
	#page-header {
		background: #32a3cb;
	}
	#page-header,#page-header a,#page-header a:visited,#page-header a:hover,#page-header #page-header-title {
		color: #ffffff;
	}
	#page-header #page-header-tagline {
		color: rgba(255, 255, 255, 0.9);
	}
	</style>
	




<script type="text/javascript">
	<!--
	var $ctx = '';
	var $basePath = 'http://openlaw.cn:80'; 
	var $svc = {
			rest : $ctx + '/service/rest/',
			filesystem : $ctx + '/service/rest/tk.File/',
		};
	
	document.write("<script" + " type=\"text/javascript\" src=\"/js/user.js.jsp\"></" + "script>");
	//-->
	
</script>
<script type="text/javascript" src="/js/trace.js.jsp"></script>

</head>
<body class="single single-format-standard">
    <div id="ht-site-container" class="clearfix">
        





		<header id="site-header" class="clearfix">
			<div class="ht-container clearfix">
				<!-- #logo -->
				<div id="logo">
					<a title="OpenLaw" href="/"> <img alt="OpenLaw" src="/images/openlaw.png">
						<h1 class="site-title">OpenLaw</h1>
					</a>
				</div>
				<!-- /#logo -->
				<!-- #primary-nav -->
				<nav id="nav-primary" >
					<button id="ht-nav-toggle">
						<i class="fa fa-reorder"></i> 菜单
					</button>
					<div id="nav-primary-menu" class="menu-primary-nav-container">
						<ul id="menu-primary-nav" class="">
							<li><a href="/">HOME</a></li>
							<li><a href="/judgement/">裁判文书</a></li>
							<!-- <li><a href="/law/">法律法规</a></li>  -->
							<li><a href="/guidingcase/">指导案例</a></li>
							<!-- <li><a href="/discussion/">讨论区</a></li> -->
							<li><a href="/news/">新闻</a></li>
							<li><a href="/research/">研究报告</a></li>
							<li><a href="/contact.jsp">联系我们</a></li>
							<li><a href="/user">会员</a></li>
						</ul>
					</div>
				</nav>
				<!-- /#primary-nav -->
			</div>
		</header>

        






<section id="page-header" class="clearfix ">
    <div class="ht-container">
        <h1 id="page-header-title">裁判文书</h1>
        <h2 id="page-header-tagline">已有 <span id="judgementCount">31,002,789</span> 份来自全国法院依法公开的判例经过系统分析，昨日新增 7,081 份．</h2>
        <div id="ht-kb-search" class="clearfix">
            <div class="ht-kb-article-search">
                <form method="get" id="searchform" class="searchform" action="/search/judgement/default">
                    <input type="hidden" name="type" id="type"/>
                    <input type="hidden" name="typeValue" id="typeValue"/>
                    <input type="hidden" name="courtId" id="courtId" value=""/>
                    <input type="hidden" name="lawFirmId" id="lawFirmId" value=""/>
                    <input type="hidden" name="lawyerId" id="lawyerId" value=""/>
                    <input type="hidden" name="docType" id="docType_c" value=""/>
                    <input type="hidden" name="causeId" id="cause_c" value=""/>
                    <input type="hidden" name="judgeDateYear" id="judgeDate_c" value=""/>
                    <input type="hidden" id="lawSearch" name="lawSearch" value=""></input>
                    <input type="hidden" id="litigationType_c" name="litigationType" value=""></input>
                    <input type="hidden" id="judgeId" name="judgeId" value=""></input>
                    <input type="hidden" id="procedureType_c" name="procedureType" value=""></input>
                    <input type="hidden" id="judgeResult_c" name="judgeResult" value=""></input>
                    <input type="hidden" id="courtLevel_c" name="courtLevel" value=""></input>
                    <input type="hidden" id="procedureType_c" name="procedureType" value=""></input>
                    <input type="hidden" id="zone_c" name="zone" value=""></input>
                    
                    <label class="screen-reader-text" for="s">Search for:</label> 
                    <input type="text" value="" placeholder="输入关键词、律师、法官、当事人、案由等 ..." name="keyword" id="s" autocomplete="off" /> 
                    <button type="submit" id="searchsubmit">
                        <i class="fa fa-search"></i> <span>检索</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>
        <section id="page-header-breadcrumbs" class="clearfix">
            <div class="ht-container">
                <div class="ht-breadcrumbs">
                    <a href="/" class="ht-breadcrumbs-home">HOME</a> <span class="sep">/</span><a href="/judgement">裁判文书</a> <span class="sep">/</span>
                    兖州市量子科技有限责任公司与孟凡英专利权权属纠纷二审民事判决书<br />
                </div>
            </div>
        </section>
        
        <div id="primary" class="sidebar-right clearfix">
            <div class="ht-container">
                <main id="content" >
                <div id="ht-kb" class="ht-kb-single judgement">
                    <article class="ht_kb type-ht_kb status-publish format-standard hentry">
                        <header class="entry-header">
                            <h2 class="entry-title">兖州市量子科技有限责任公司与孟凡英专利权权属纠纷二审民事判决书</h2>
                            <ul class="ht-kb-entry-meta clearfix">
                                <li class="ht-kb-em-date"><span>日期：</span> 2015-09-01</li>
                                <li class="ht-kb-em-author"><span>法院：</span> <a class="url fn n" href="/court/c7c7059b2a4443429af03b7aeb5c7517" rel="me">山东省高级人民法院</a></li>
                                <li class="ht-kb-em-category"><span>案号：</span>（2015）鲁民三终字第110号</li>
                            </ul>
                        </header>
                        <div id="entry-cont" class="entry-content clearfix">
                            
                            <div class="part" id="Litigants">
                                <p>上诉人（原审被告）:孟凡英（曾用名:孟繁英）。</p><p>委托代理人:孙书</p><p>国，山东泰泉律师事务所律师。</p><p>被上诉人（原审原告）:兖州市量子科技有限责任公司。</p><p>住所地:山东省兖州市新兖镇工业园区。</p><p>法定代表人:刘素华，董事长。</p><p>委托代理人:刘庆飞，科技有限责任公司员工。</p>

                            </div>
                            
                            <div class="part" id="Explain">
                                <p>上诉人孟凡英因与被上诉人兖州市量子科技有限责任公司（以下简称量子公司）专利权权属纠纷一案，不服山东省济南市中级人民法院</p>

                            </div>
                            
                            <div class="part" id="Procedure">
                                <p>（2013）济民三初字第705号</p><p>民事判决，向本院提起上诉。</p><p>本院依法组成合议庭，公开开庭审理了本案。</p><p>上诉人孟凡英及其委托代理人孙书</p><p>国，被上诉人量子公司的委托代理人刘庆飞到庭参加诉讼。</p><p>本案现已审理终结。</p><p>量子公司在原审中诉称，名称为“掘进机用甲带运输机”（专利号</p><p>为200820129833.8）的实用新型专利是量子公司投入了大量的人力、物力、财力指令</p><p>孟凡英等人完成的技术创新，属于量子公司所有的发明创造。</p><p>但孟凡英将该专利权据为己有，侵害了量子公司的权益，请求法院</p><p>判令</p><p>:涉案专利权人为量子公司；孟凡英承担本案的诉讼费用及合理支出费用。</p><p>原审法院</p>

                            </div>
                            
                            <div class="part" id="Facts">
                                <p>经审理查明，南京市公安局中央门派出所登记的居民户口簿载明，孟凡英的曾用名为孟繁英。</p><p>名称为“掘进机用甲带运输机”的实用新型专利证书</p><p>载明，发明人为杜昌峰、孟凡英，专利权人为孟凡英，专利号</p><p>为200820129833.8，专利申请日为2008年12月22日，授权公告日为2010年4月28日。</p><p>该实用新型专利公告文本中载明的专利权人联系地址为山东省兖州市新兖镇民营工业园振兴路。</p><p>2009年2月至2010年12月，涉案专利权年费缴纳收据均记载缴款人为量子公司。</p><p>量子公司成立于2001年2月16日，注册资本为1166万元，法定代表人为刘素华，公司经营范围为设计、制造、安装机电设备、环保设备。</p><p>兖州市工商行政管理局出具的量子公司的企业变更情况载明，2006年2月27日，量子公司的董事会成员、监事会成员、经理情况发生变更，变更前后均有孟凡英的信息；2006年6月29日，量子公司的自然人股东发生变更，孟凡英的出资额由50万变更为93.04万；2011年7月19日，量子公司的董事会成员、监事会成员、经理情况发生变更，变更前后孟凡英的身份均为副董事长；2011年7月27日，量子公司的董事会成员、监事会成员、经理情况和股东（发起人）均发生变更，变更后均无孟凡英的信息。</p><p>庭审中，刘素华与孟凡英均认可双方的婚姻关系于2011年8月16日解除。</p><p>量子公司提供了2002年至2010年其公司的购物申请单、派工单、经营开支报销清单、采购报销清单、招待费报销清单、汽油报销清单、出差人员报销清单等报销单据及2004年10月至2006年4月的员工工资表，上述证据均有孟凡英的签字。</p><p>孟凡英对其签字的真实性没有异议。</p><p>量子公司提供了2008年12月20日其与孟凡英签订的劳动合同，合同盖有兖州市劳动和社会保障局劳动合同鉴证专用章。</p><p>劳动合同期限自2008年12月20日至2013年12月20日，孟凡英的任职部门为设计院，职位为总工，工种为机械设计。</p><p>孟凡英对劳动合同上孟凡英签字的真实性没有异议。</p><p>原审法院</p><p>认为，根据我国专利法的有关规定，职务发明创造申请专利的权利属于单位；申请被批准后，该单位为专利权人。</p><p>判断一项发明创造是否是职务发明创造，应当以是否是执行本单位的任务或者主要是利用本单位的物质技术条件为标准。</p><p>执行本单位的任务所完成的职务发明创造包括:在本职工作中作出的发明创造；履行本单位交付的本职工作之外的任务所作出的发明创造；退休、调离原单位后或者劳动、人事关系终止后1年内作出的，与其在原单位承担的本职工作或者原单位分配的任务有关的发明创造。</p><p>孟凡英原为量子公司的股东、副董事长，系量子公司法定代表人刘素华的前夫。</p><p>量子公司提供的2002年以来孟凡英签字的工资表、报销单据、劳动合同及证人证言等相互关联的证据，已经形成完整的证据链，足以证明孟凡英在涉案专利申请前后与量子公司存在劳动关系，参与了量子公司的经营管理，领取了劳动报酬，是量子公司负责机械设计的技术总工。</p><p>涉案发明创造是一种机械设备，是与孟凡英在量子公司承担的本职工作有关的发明创造，符合职务发明创造的构成要件。</p><p>且涉案专利年费一直由量子公司缴纳，孟凡英2009年出具的书</p><p>面声明也承认其在量子公司工作期间的发明创造均为职务发明。</p><p>因此，涉案发明创造应为职务发明创造，该职务发明创造申请专利的权利及其授予的专利权应属于孟凡英曾经的工作单位量子公司。</p><p>孟凡英虽抗辩量子公司对孟凡英申请专利是明知的，但不能以量子公司明知而认定量子公司放弃了自己的权利。</p><p>本案系侵权引起的专利权属纠纷，量子公司在提起诉讼时，涉案专利权仍然登记在孟凡英名下，侵权仍处于持续的状态，量子公司此时主张权利不应受诉讼时效的限制，对孟凡英提出的诉讼时效抗辩原审法院</p><p>不予支持。</p><p>量子公司虽主张孟凡英应承担制止侵权的合理费用，但未提供相应的证据佐证，对该项诉讼请求原审法院</p><p>不予支持。</p><p>原审法院</p><p>依照《<a target="_blank" href="/law/c66b4f684ff848b4bad4fc5db554cded">中华人民共和国专利法</a>》<a href="#" id="law_6Article"  class="popover-button-default"  data-content="第六条&nbsp;&lt;br/&gt;执行本单位的任务或者主要是利用本单位的物质技术条件所完成的发明创造为职务发明创造。职务发明创造申请专利的权利属于该单位；申请被批准后，该单位为专利权人。&nbsp;&lt;br/&gt;非职务发明创造，申请专利的权利属于发明人或者设计人；申请被批准后，该发明人或者设计人为专利权人。&nbsp;&lt;br/&gt;利用本单位的物质技术条件所完成的发明创造，单位与发明人或者设计人订有合同，对申请专利的权利和专利权的归属作出约定的，从其约定。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/c66b4f684ff848b4bad4fc5db554cded#6Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第六条" data-trigger="click" data-placement="top" >第六条 </a>&nbsp;<a href="#" id="law_6Article1Paragraph"  class="popover-button-default"  data-content="执行本单位的任务或者主要是利用本单位的物质技术条件所完成的发明创造为职务发明创造。职务发明创造申请专利的权利属于该单位；申请被批准后，该单位为专利权人。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/c66b4f684ff848b4bad4fc5db554cded#6Article1Paragraph&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一款" data-trigger="click" data-placement="top" >第一款 </a>&nbsp;、《<a target="_blank" href="/law/3a9f2709997a424eb287b5f69f903472">中华人民共和国专利法实施细则</a>》<a href="#" id="law_12Article"  class="popover-button-default"  data-content="第十二条&nbsp;&lt;br/&gt;专利法第六条所称执行本单位的任务所完成的职务发明创造，是指:&nbsp;&lt;br/&gt;（一）在本职工作中作出的发明创造；&nbsp;&lt;br/&gt;（二）履行本单位交付的本职工作之外的任务所作出的发明创造；&nbsp;&lt;br/&gt;（三）退休、调离原单位后或者劳动、人事关系终止后1年内作出的，与其在原单位承担的本职工作或者原单位分配的任务有关的发明创造。&nbsp;&lt;br/&gt;专利法第六条所称本单位，包括临时工作单位；专利法第六条所称本单位的物质技术条件，是指本单位的资金、设备、零部件、原材料或者不对外公开的技术资料等。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/3a9f2709997a424eb287b5f69f903472#12Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第十二条" data-trigger="click" data-placement="top" >第十二条 </a>&nbsp;<a href="#" id="law_12Article1Paragraph"  class="popover-button-default"  data-content="专利法第六条所称执行本单位的任务所完成的职务发明创造，是指:&nbsp;&lt;br/&gt;（一）在本职工作中作出的发明创造；&nbsp;&lt;br/&gt;（二）履行本单位交付的本职工作之外的任务所作出的发明创造；&nbsp;&lt;br/&gt;（三）退休、调离原单位后或者劳动、人事关系终止后1年内作出的，与其在原单位承担的本职工作或者原单位分配的任务有关的发明创造。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/3a9f2709997a424eb287b5f69f903472#12Article1Paragraph&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一款" data-trigger="click" data-placement="top" >第一款 </a>&nbsp;、《最高人民法院</p><p>关于审理专利纠纷案件适用法律问题的若干规定》第二十三条、《<a target="_blank" href="/law/eb5d33fa469a4e7c96a6c012548054de">中华人民共和国民事诉讼法</a>》<a href="#" id="law_64Article"  class="popover-button-default"  data-content="第六十四条&nbsp;&lt;br/&gt;当事人对自己提出的主张，有责任提供证据。&nbsp;&lt;br/&gt;当事人及其诉讼代理人因客观原因不能自行收集的证据，或者人民法院认为审理案件需要的证据，人民法院应当调查收集。&nbsp;&lt;br/&gt;人民法院应当按照法定程序，全面地、客观地审查核实证据。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/eb5d33fa469a4e7c96a6c012548054de#64Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第六十四条" data-trigger="click" data-placement="top" >第六十四条 </a>&nbsp;<a href="#" id="law_64Article1Paragraph"  class="popover-button-default"  data-content="当事人对自己提出的主张，有责任提供证据。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/eb5d33fa469a4e7c96a6c012548054de#64Article1Paragraph&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一款" data-trigger="click" data-placement="top" >第一款 </a>&nbsp;之规定，判决:一、名称为“掘进机用甲带运输机”实用新型专利权（专利号</p><p>为200820129833.8）属于量子公司；二、驳回量子公司的其他诉讼请求。</p><p>案件受理费1000元、财产保全费1020元，两项合计2020元，由孟凡英负担。</p><p>上诉人孟凡英不服上述判决，向本院提起上诉，请求撤销上述判决，改判驳回量子公司的诉讼请求，一、二审诉讼费用均由量子公司负担。</p><p>其主要理由为:原审判决认定事实不清，证据不足，涉案专利既不是孟凡英在量子公司工作期间在本职工作中完成的发明创造，也不是主要利用量子公司的物质技术条件完成的发明创造，孟凡英应系涉案专利的专利权人。</p><p>1、量子公司与孟凡英的劳动合同对专利权属没有约定。</p><p>孟凡英的声明也不能证明涉案专利权归属量子公司，并且专利权年费系量子公司缴纳，量子公司以其实际行动认可专利权人是孟凡英。</p><p>2、量子公司在原审中提供的采购报销清单等票据与专利的研发没有关联性，量子公司提供的其他证据亦无法证明孟凡英全部或大部分利用量子公司的物质条件，也无法证明上述物质条件对形成涉案专利技术具有实质性的影响。</p><p>3、本案中量子公司的起诉已超过二年诉讼时效。</p><p>被上诉人量子公司答辩称，原审判决认定涉案专利为职务发明创造事实清楚、证据确凿，符合相关法律规定，本案诉讼亦未超过二年诉讼时效。</p><p>二审中，孟凡英为证明其系涉案专利的专利权人提交以下证据:证据1、孟凡英高级工程师资格证书</p><p>原件一份，拟证明孟凡英自1994年就取得高级技术职称，具有从事发明创造的能力。</p><p>证据2、孟凡英与量子公司的约定书</p><p>原件一份，拟证明量子公司提交的孟凡英声明系量子公司用孟凡英签字的空白纸填写，不是孟凡英的真实意思表示。</p><p>证据3、孟凡英1991年-2011年期间取得的30多项专利证书</p><p>复印件一宗，拟证明孟凡英在到量子公司工作之前就已从事发明创造，其创造过程是连续的。</p><p>量子公司质证称，对上述证据的真实性均有异议，且与本案无关。</p>

                            </div>
                            
                            <div class="part" id="Opinion">
                                <p>本院认为，证据3系复印件，且量子公司对其提出异议，本院对证据3的真实性不予确认；证据1、2均系原件，本院对其真实性予以确认，对其证明力将结合本案其他证据予以综合认定评判。</p><p>本院二审查明的事实与原审法院</p><p>查明的一致。</p><p>本院认为，本案当事人争议的焦点问题是:一、涉案专利的专利权人是孟凡英还是量子公司。</p><p>二、量子公司的起诉是否超过诉讼时效。</p><p>一、关于涉案专利的专利权人是孟凡英还是量子公司的问题。</p><p>本院认为，《<a target="_blank" href="/law/c66b4f684ff848b4bad4fc5db554cded">中华人民共和国专利法</a>》<a href="#" id="law_6Article"  class="popover-button-default"  data-content="第六条&nbsp;&lt;br/&gt;执行本单位的任务或者主要是利用本单位的物质技术条件所完成的发明创造为职务发明创造。职务发明创造申请专利的权利属于该单位；申请被批准后，该单位为专利权人。&nbsp;&lt;br/&gt;非职务发明创造，申请专利的权利属于发明人或者设计人；申请被批准后，该发明人或者设计人为专利权人。&nbsp;&lt;br/&gt;利用本单位的物质技术条件所完成的发明创造，单位与发明人或者设计人订有合同，对申请专利的权利和专利权的归属作出约定的，从其约定。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/c66b4f684ff848b4bad4fc5db554cded#6Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第六条" data-trigger="click" data-placement="top" >第六条 </a>&nbsp;<a href="#" id="law_6Article1Paragraph"  class="popover-button-default"  data-content="执行本单位的任务或者主要是利用本单位的物质技术条件所完成的发明创造为职务发明创造。职务发明创造申请专利的权利属于该单位；申请被批准后，该单位为专利权人。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/c66b4f684ff848b4bad4fc5db554cded#6Article1Paragraph&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一款" data-trigger="click" data-placement="top" >第一款 </a>&nbsp;规定，执行本单位的任务或者主要是利用本单位的物质技术条件所完成的发明创造为职务发明创造。</p><p>职务发明创造申请专利的权利属于该单位；申请被批准后，该单位为专利权人。</p><p>《<a target="_blank" href="/law/3a9f2709997a424eb287b5f69f903472">中华人民共和国专利法实施细则</a>》<a href="#" id="law_12Article"  class="popover-button-default"  data-content="第十二条&nbsp;&lt;br/&gt;专利法第六条所称执行本单位的任务所完成的职务发明创造，是指:&nbsp;&lt;br/&gt;（一）在本职工作中作出的发明创造；&nbsp;&lt;br/&gt;（二）履行本单位交付的本职工作之外的任务所作出的发明创造；&nbsp;&lt;br/&gt;（三）退休、调离原单位后或者劳动、人事关系终止后1年内作出的，与其在原单位承担的本职工作或者原单位分配的任务有关的发明创造。&nbsp;&lt;br/&gt;专利法第六条所称本单位，包括临时工作单位；专利法第六条所称本单位的物质技术条件，是指本单位的资金、设备、零部件、原材料或者不对外公开的技术资料等。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/3a9f2709997a424eb287b5f69f903472#12Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第十二条" data-trigger="click" data-placement="top" >第十二条 </a>&nbsp;<a href="#" id="law_12Article1Paragraph"  class="popover-button-default"  data-content="专利法第六条所称执行本单位的任务所完成的职务发明创造，是指:&nbsp;&lt;br/&gt;（一）在本职工作中作出的发明创造；&nbsp;&lt;br/&gt;（二）履行本单位交付的本职工作之外的任务所作出的发明创造；&nbsp;&lt;br/&gt;（三）退休、调离原单位后或者劳动、人事关系终止后1年内作出的，与其在原单位承担的本职工作或者原单位分配的任务有关的发明创造。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/3a9f2709997a424eb287b5f69f903472#12Article1Paragraph&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一款" data-trigger="click" data-placement="top" >第一款 </a>&nbsp;<a href="#" id="law_12Article1Paragraph1List"  class="popover-button-default"  data-content="（一）在本职工作中作出的发明创造；&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/3a9f2709997a424eb287b5f69f903472#12Article1Paragraph1List&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第（一）项" data-trigger="click" data-placement="top" >第（一）项 </a>&nbsp;规定，在本职工作中作出的发明创造是专利法<a href="#" id="law_6Article"  class="popover-button-default"  data-content="第六条&nbsp;&lt;br/&gt;当事人因不可抗拒的事由而延误专利法或者本细则规定的期限或者国务院专利行政部门指定的期限，导致其权利丧失的，自障碍消除之日起2个月内，最迟自期限届满之日起2年内，可以向国务院专利行政部门请求恢复权利。&nbsp;&lt;br/&gt;除前款规定的情形外，当事人因其他正当理由延误专利法或者本细则规定的期限或者国务院专利行政部门指定的期限，导致其权利丧失的，可以自收到国务院专利行政部门的通知之日起2个月内向国务院专利行政部门请求恢复权利。&nbsp;&lt;br/&gt;当事人依照本条第一款或者第二款的规定请求恢复权利的，应当提交恢复权利请求书，说明理由，必要时附具有关证明文件，并办理权利丧失前应当办理的相应手续；依照本条第二款的规定请求恢复权利的，还应当缴纳恢复权利请求费。&nbsp;&lt;br/&gt;当事人请求延长国务院专利行政部门指定的期限的，应当在期限届满前，向国务院专利行政部门说明理由并办理有关手续。&nbsp;&lt;br/&gt;本条第一款和第二款的规定不适用专利法第二十四条、第二十九条、第四十二条、第六十八条规定的期限。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/3a9f2709997a424eb287b5f69f903472#6Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第六条" data-trigger="click" data-placement="top" >第六条 </a>&nbsp;所称执行本单位的任务所完成的职务发明创造。</p><p>本案中，量子公司与孟凡英签订的劳动合同表明，孟凡英在量子公司设计院任职，职位为总工，工种为机械设计。</p><p>孟凡英在庭审中亦自认其自2001年公司成立到2011离开公司一直在量子公司担任技术负责人，涉案专利也是孟凡英在此期间完成的，且量子公司与孟凡英亦均认可其公司业务主要是矿用设备的设计、制造，而涉案专利也是矿用设备，孟凡英对此也无异议。</p><p>本院认为，综合上述事实能够认定涉案专利系孟凡英在量子公司工作期间在本职工作中完成的发明创造，系职务发明创造，涉案专利权人应为量子公司。</p><p>虽然孟凡英二审提交的高级工程师资格证书</p><p>能够证明其具有一定的发明创造能力，但其具有相关能力与涉案专利权归属并无直接因果关系，孟凡英关于涉案专利权应归其所有的主张不能成立。</p><p>二、关于量子公司的起诉是否超过诉讼时效的问题。</p><p>《最高人民法院</p><p>关于审理专利纠纷案件适用法律问题的若干规定》第二十三条规定，侵犯专利权的诉讼时效为二年，自专利权人或者利害关系人知道或者应当知道侵权行为之日起计算。</p><p>权利人超过二年起诉的，如果侵权行为在起诉时仍在继续，在该项专利权有效期内，人民法院</p><p>应当判决停止侵权行为，侵权损害赔偿数额应当自权利人向人民法院</p><p>起诉之日起向前推算二年计算。</p><p>本案中，由于量子公司起诉时，涉案专利权仍然登记在孟凡英名下，孟凡英的行为属于持续状态，量子公司在涉案专利的有效期内提起诉讼并未超过诉讼时效。</p><p>孟凡英关于量子公司的起诉超过诉讼时效的主张亦不能成立。</p><p>综上，上诉人孟凡英的上诉主张缺乏事实与法律依据，其上诉请求不能成立，应予驳回；原审判决认定事实清楚，适用法律正确，应予维持。</p>

                            </div>
                            
                            <div class="part" id="Verdict">
                                <p>依据《<a target="_blank" href="/law/eb5d33fa469a4e7c96a6c012548054de">中华人民共和国民事诉讼法</a>》<a href="#" id="law_170Article"  class="popover-button-default"  data-content="第一百七十条&nbsp;&lt;br/&gt;第二审人民法院对上诉案件，经过审理，按照下列情形，分别处理:&nbsp;&lt;br/&gt;（一）原判决、裁定认定事实清楚，适用法律正确的，以判决、裁定方式驳回上诉，维持原判决、裁定；&nbsp;&lt;br/&gt;（二）原判决、裁定认定事实错误或者适用法律错误的，以判决、裁定方式依法改判、撤销或者变更；&nbsp;&lt;br/&gt;（三）原判决认定基本事实不清的，裁定撤销原判决，发回原审人民法院重审，或者查清事实后改判；&nbsp;&lt;br/&gt;（四）原判决遗漏当事人或者违法缺席判决等严重违反法定程序的，裁定撤销原判决，发回原审人民法院重审。&nbsp;&lt;br/&gt;原审人民法院对发回重审的案件作出判决后，当事人提起上诉的，第二审人民法院不得再次发回重审。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/eb5d33fa469a4e7c96a6c012548054de#170Article&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一百七十条" data-trigger="click" data-placement="top" >第一百七十条 </a>&nbsp;<a href="#" id="law_170Article1Paragraph"  class="popover-button-default"  data-content="第二审人民法院对上诉案件，经过审理，按照下列情形，分别处理:&nbsp;&lt;br/&gt;（一）原判决、裁定认定事实清楚，适用法律正确的，以判决、裁定方式驳回上诉，维持原判决、裁定；&nbsp;&lt;br/&gt;（二）原判决、裁定认定事实错误或者适用法律错误的，以判决、裁定方式依法改判、撤销或者变更；&nbsp;&lt;br/&gt;（三）原判决认定基本事实不清的，裁定撤销原判决，发回原审人民法院重审，或者查清事实后改判；&nbsp;&lt;br/&gt;（四）原判决遗漏当事人或者违法缺席判决等严重违反法定程序的，裁定撤销原判决，发回原审人民法院重审。&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/eb5d33fa469a4e7c96a6c012548054de#170Article1Paragraph&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第一款" data-trigger="click" data-placement="top" >第一款 </a>&nbsp;<a href="#" id="law_170Article1Paragraph1List"  class="popover-button-default"  data-content="（一）原判决、裁定认定事实清楚，适用法律正确的，以判决、裁定方式驳回上诉，维持原判决、裁定；&nbsp;&lt;a title=&quot;点击查看该法条&quot; target=&quot;_blank&quot; href=&quot;/law/eb5d33fa469a4e7c96a6c012548054de#170Article1Paragraph1List&quot;&gt;&lt;span style=&quot;font-size:8px;&quot;&gt;&lt;i class=&quot;fa fa-external-link&quot;&gt;&lt;/i&gt;&lt;/span&gt;&lt;/a&gt;&nbsp;" title="第（一）项" data-trigger="click" data-placement="top" >第（一）项 </a>&nbsp;之规定，判决如下:驳回上诉，维持原判。</p><p>二审案件受理费1000元，由上诉人孟凡英负担。</p>

                            </div>
                            
                            <div class="part" id="Inform">
                                <p>本判决为终审判决。</p>

                            </div>
                            
                            <div class="part" id="Ending">
                                <p>审判长马莉莉审判员戴磊代理审判员于志涛二〇一五年九月一日书记员于明君</p>

                            </div>
                            
                        </div>
                        <div id="ht-kb-rate-article">
                        	
                        	<div class="tags">
                        		<strong>标签：</strong>
                        		
                        			<a href="/search/judgement/default?tagId=813ab9ac39194d14a85ef34950c3eb35" rel="tag">劳动合同</a>
                        		
                        			<a href="/search/judgement/default?tagId=bd9c47702c364195a050b012f504d69d" rel="tag">专利</a>
                        		
                        			<a href="/search/judgement/default?tagId=a2b909e7ad8a4398ac6de562ca79bece" rel="tag">损害赔偿</a>
                        		
                        			<a href="/search/judgement/default?tagId=dccf00d331ba4c0b9c67b991fe6800e3" rel="tag">专利权</a>
                        		
                        			<a href="/search/judgement/default?tagId=4a8c395a82ba41b89f6e81636b0ec461" rel="tag">代理</a>
                        		
                        			<a href="/search/judgement/default?tagId=1bb5ee2011f24ba987777adc9f9e85eb" rel="tag">诉讼时效</a>
                        		
                        			<a href="/search/judgement/default?tagId=cadb8fe67fdf4b04b7146ea04975cc1f" rel="tag">工资表</a>
                        		
                        			<a href="/search/judgement/default?tagId=6e3bde60a3584055a525e12a9857293a" rel="tag">委托</a>
                        		
                        	</div>
                        	
                        </div>
                        <div id="entry-review-add" class="clearfix">
                            <a id="addReviews" href="/reviews/add?targetUri=opendata.Judgement:c991df9fd78442ddba1e4f469f1f127c" target="_blank"><i class="fa fa-pencil-square-o"></i> 我来评论这个判例</a>
                        </div>
                        
                       





<section id="ht-kb-related-articles" class="clearfix">
	<h3 id="ht-kb-related-articles-title">短评 / 批注</h3>
	
	<span>目前没有短评 / 批注</span>
	
</section>
<script type="text/javascript">
      (function($){
    	  $('.comments-click').click(function(){
    		  var id = $(this).attr("data-id");
    		  $.ajax({
    			  type : "get",
    			  url : "/lhComment?like=true&commentId=" + id,
    			  dataType : "json",
    			  success : function(data) {
                      var code = data.code;
                      if (code == 1) {
                    	  var like = data.result.like;
                    	  $('#c_l_s' + id).text(like);
                      }
    			  }
    		  });
    	  });
      })(jQuery);
 </script>
                       






<div id="respond" class="comment-respond">
    <h3 id="reply-title" class="comment-reply-title">
        发表简短评论? 
    </h3>
    <form method="post" id="form-comment" class="comment-form" onsubmit="return false;">
        <input type="hidden" name="_csrf" value="ec1ccefa-7511-4d3d-8b5d-fbc47bac7bea"/>
        
        <p>
            你必须登录后才能发表评论，点击 <a href="/login.jsp?returnTo=%2Fjudgement%2Fc991df9fd78442ddba1e4f469f1f127c">登录</a>
        </p>
        
    </form>
</div>
<script type='text/javascript'>
        var $ = jQuery;
        $(document).ready(function(){
            $('#submit').click(function () {
                if ($('#comment').val().length > 140) {
                    $('#submit_warn').show();
                    setTimeout(function(){
                        $('#submit_warn').hide();
                    }, 2000);
                } else {
                     $.post("/service/rest/opendata.Comment/collection/addComment", {
                    	    _csrf:"ec1ccefa-7511-4d3d-8b5d-fbc47bac7bea",
                    	 	targetUri: 'opendata.Judgement:c991df9fd78442ddba1e4f469f1f127c',
                            commenter:   $("input#commenter").val(),
                            contact:   $("commenter#contact").val(),
                            content:   $("textarea#comment").val(),
                            validateCode:   $("input#validateCode").val()
                        }, function(data) {
                             if (data == 1) {
                                location.reload();
                            } else if (data == -4) {
                                alert("系统对你所在的网络已经禁止了发表评论！");
                            } else if (data == -3) {
                                alert("验证码错误，请重新输入！");
                                $("input#validateCode").focus();
                            } else {
                                alert("系统发生错误，提交失败！可联系 021-51697170");
                            }
                        });
                     }
                });
            
            $('#updateComment').click(function(){
                if ($('#comment').val().length > 140) {
                    $('#submit_warn').show();
                    setTimeout(function(){
                        $('#submit_warn').hide();
                    }, 2000);
                } else {
                     $.post("/service/rest/opendata.Comment//update", {
                    	 	_csrf:"ec1ccefa-7511-4d3d-8b5d-fbc47bac7bea",
                    	 	content:   $("textarea#comment").val()
                        }, function(data) {
                             if (data.code == 1) {
                            	var url = location.href;
                            	url = url.split("?")[0] + "#respond";
                            	window.location = url;
                            } else {
                                alert("系统发生错误，提交失败！可联系 021-51697170");
                            }
                        });
                     }
             });
         });

        function refreshValidateCode(){
			var kaptcha = document.getElementById('kaptcha');
			kaptcha.src = '/Kaptcha?v=' + new Date().getTime();
		}

        </script>
                    </article>
                </div>
                </main>

                <aside id="sidebar" >
                    
                    <section class="widget HT_KB_Authors_Widget clearfix">
                        <h4 class="widget-title">案件信息</h4>
                        <ul class="clearfix">
                            <li class="clearfix ht-kb-pf-standard">案号：（2015）鲁民三终字第110号</li>
                            <li class="clearfix ht-kb-pf-standard">法院：山东省高级人民法院</li>
                            <li class="clearfix ht-kb-pf-standard">时间：2015年09月01日</li>
                            <li class="clearfix ht-kb-pf-standard">案由：专利权权属纠纷</li>
                            
                            <li class="clearfix ht-kb-pf-standard">类型：判决书</li>
                            
                            
                            <li class="clearfix ht-kb-pf-standard">程序：二审</li>
                            
                        </ul>
                    </section>
                    <section class="widget HT_KB_Authors_Widget clearfix">
                        <h4 class="widget-title">案件相关人</h4>
                        <ul class="clearfix">
                            
                            <li class="clearfix has-avatar">
                                <div class="ht-kb-author-avatar">
                                    <a href="javascript:void(0)" rel="nofollow"> <img alt="" src="/images/avatars/person.png" class="avatar avatar-32 photo" height="32" width="32"></a>
                                </div>
                                
                                孟凡英
                                
                                <div class="ht-kb-authored-count">
                                    上诉人
                                </div>
                            </li>
                            
                            <li class="clearfix has-avatar">
                                <div class="ht-kb-author-avatar">
                                    <a href="javascript:void(0)" rel="nofollow"> <img alt="" src="/images/avatars/lawyer.png" class="avatar avatar-32 photo" height="32" width="32"></a>
                                </div>  孙书 
                                <div class="ht-kb-authored-count">
                                    委托代理人
                                    
                                    
                                    
                                </div>
                            </li>
                            
                            <li class="clearfix has-avatar">
                                <div class="ht-kb-author-avatar">
                                    <a href="javascript:void(0)" rel="nofollow"> <img alt="" src="/images/avatars/person.png" class="avatar avatar-32 photo" height="32" width="32"></a>
                                </div>兖州市量子科技有限责任公司
                                <div class="ht-kb-authored-count">
                                    被上诉人
                                </div>
                            </li>
                            
                            <li class="clearfix has-avatar">
                                <div class="ht-kb-author-avatar">
                                    <a href="javascript:void(0)" rel="nofollow"> <img alt="" src="/images/avatars/person.png" class="avatar avatar-32 photo" height="32" width="32"></a>
                                </div>  刘庆飞 
                                <div class="ht-kb-authored-count">
                                    委托代理人
                                    
                                    
                                    
                                </div>
                            </li>
                            
                            <li class="clearfix has-avatar">
                                <div class="ht-kb-author-avatar">
                                    <a href="javascript:void(0)" rel="nofollow"> <img alt="" src="/images/avatars/judge.png" class="avatar avatar-32 photo" height="32" width="32"></a>
                                </div>  马莉莉 
                                <div class="ht-kb-authored-count">审判长</div>
                            </li>
                            
                        </ul>
                    </section>
                    <section class="widget HT_KB_Articles_Widget clearfix">
                        <ul class="clearfix">
                            
                                <li id="annotationSwitch" class="clearfix has-thumb ht-kb-pf-standard annotation"><a class="widget-entry-title" href="javascript:void(0);" target="_blank">隐藏批注</a></li>
                            
                            
                                <li class="clearfix has-thumb ht-kb-pf-standard favorite-o"><a class="widget-entry-title" href="javascript:void(0);">加入收藏</a></li>
                            
                            <li class="clearfix has-thumb ht-kb-pf-standard" id="print"><a class="widget-entry-title" href="/print/judgement/c991df9fd78442ddba1e4f469f1f127c" target="_blank">打印文书</a></li>
                            <li class="clearfix has-thumb ht-kb-pf-standard" id="download"><a class="widget-entry-title" href="/pdf/judgement/c991df9fd78442ddba1e4f469f1f127c" target="_blank">下载 PDF</a></li>
                            <li class="clearfix has-thumb ht-kb-pf-standard" id="govlinks"><a class="widget-entry-title" href="gov-links.jsp?id=c991df9fd78442ddba1e4f469f1f127c">官方链接</a></li>
                            <li class="clearfix has-thumb ht-kb-pf-standard" id="block"><a class="widget-entry-title" href="/complaint?id=c991df9fd78442ddba1e4f469f1f127c&caseNo=（2015）鲁民三终字第110号">申请撤下</a></li>
                            
                            <li class="clearfix has-thumb ht-kb-pf-standard" id="report"><a class="widget-entry-title"
                                href="/feedback/?url=%2Fjudgement%2Fc991df9fd78442ddba1e4f469f1f127c">报告错误</a></li>
                            <li class="clearfix has-thumb ht-kb-pf-standard" id="share"><div class="bdsharebuttonbox"><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_twi" data-cmd="twi" title="分享到Twitter"></a><a href="#" class="bds_fbook" data-cmd="fbook" title="分享到Facebook"></a><a href="#" class="bds_more" data-cmd="more"></a></div></li>
                        </ul>
                    </section>
                </aside>
            </div>
        </div>
        




<section id="site-footer-widgets">
	<div class="ht-container">
		<div class="ht-grid ht-grid-gutter-20">
			<section id="text-2" class="widget widget_text ht-grid-col ht-grid-4">
				<h4 class="widget-title">关于 OpenLaw</h4>
				<div class="textwidget">
					<p>OpenLaw 开放法律联盟，2014年成立于上海。</p>
					<p>是一个面向律师、法官、检察官、法学教师、学者、学生以及从事法律相关的工作人员的 NGO 开放型组织，OpenLaw 的用户被视为法律技术和知识的源泉，共同分享法律专业知识以及智慧和经验成果。</p>
				</div>
			</section>
			<section id="ht-posts-widget-plugin-2" class="widget HT_Posts_Widget_Plugin ht-grid-col ht-grid-4">
				<h4 class="widget-title">最新新闻</h4>
				<ul class="clearfix">
					
					<li class="clearfix has-thumb">
						<div class="widget-entry-thumb">
						
							<a href="/news/1514232483b1b308f63c48ba7f5429b1" rel="nofollow" target="_blank">
							    <img src="/service/rest/tk.File/4652187dd603469faf5306c7beef8a51/view?thumb=60x60" width="60" height="36" class="attachment-post-thumbnail wp-post-image" alt="最高人民法院发布第11批指导性案例 " />
							</a>
						</div> <a class="widget-entry-title" href="/news/1514232483b1b308f63c48ba7f5429b1" rel="bookmark" title="最高人民法院发布第11批指导性案例 "  target="_blank">最高人民法院发布第11批指导性案例 </a>
					</li>
					
					<li class="clearfix has-thumb">
						<div class="widget-entry-thumb">
						
							<a href="/news/15045f7b20330035e58c4e7ef303a234" rel="nofollow" target="_blank">
							    <img src="/images/article.png" width="60" height="36" class="attachment-post-thumbnail wp-post-image" alt="对“关于解决在裁判文书上隐藏个人信息”问题的答复" />
							</a>
						</div> <a class="widget-entry-title" href="/news/15045f7b20330035e58c4e7ef303a234" rel="bookmark" title="对“关于解决在裁判文书上隐藏个人信息”问题的答复"  target="_blank">对“关于解决在裁判文书上隐藏个人信息”问题的答复</a>
					</li>
					
				</ul>
			</section>
			<section id="ht-social-widget-2" class="widget HT_Social_Widget_Display ht-grid-col ht-grid-4" style="margin-bottom: 0px;">
				<h4 class="widget-title">社交</h4>
				<ul class="ht-social-media-list clearfix">
					<li><a href="https://www.facebook.com/openlawcn" target="_blank"><i class="fa fa-facebook-square" style="color: #3b5998; background-color:;" title=""></i></a></li>
					<li><a href="https://twitter.com/openlawcn" target="_blank"><i class="fa fa-twitter-square" style="color: #55acee; background-color:;" title=""></i></a></li>
					<li><a href="https://plus.google.com/communities/106089734977395259294" target="_blank"><i class="fa fa-google-plus-square" style="color: #dd4b39; background-color:;" title=""></i></a></li>
				</ul>
				<img alt="OpenLaw微信公众号" src="/images/openlaw-wechat-258.jpg" width="140" height="140"/>
			</section>
		</div>
	</div>
</section>
<footer id="site-footer" class="clearfix">
	<div class="ht-container">
		<small id="copyright">© Copyright <a href="http://openlaw.cn">OpenLaw</a>.  <a href="http://www.miitbeian.gov.cn" target="_blank">沪ICP备05051100号-19</a>
			<a href="http://www.zx110.org/picp/?sn=310104100043703" target="_blank"><img alt="" style="height:12px" src="http://static.homolo.net/common/images/beian/openlaw.png"></a>
		</small>
	</div>
	
</footer>
<script type='text/javascript' src="http://static.openlaw.cn/theme/helpguru/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js"></script>
<script type='text/javascript' src="http://static.openlaw.cn/theme/helpguru/wp-content/plugins/bbpress/templates/default/js/editor.js"></script>
<script type='text/javascript' src="http://static.openlaw.cn/theme/helpguru/wp-content/themes/helpguru/js/functions.js"></script>
<script type='text/javascript' src="/js/typeahead/bloodhound.min.js"></script>
<script type='text/javascript' src="/js/typeahead/typeahead.bundle.min.js"></script>
<script type='text/javascript' src="/js/typeahead/typeahead.jquery.min.js"></script>
<script type='text/javascript' src="/js/typeahead/handlebars.js"></script>
<script type='text/javascript' src="/js/tools.js"></script>

<script type='text/javascript' >
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?a105f5952beb915ade56722dc85adf05";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

<script type='text/javascript' >
//baidu share
window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
</script>

        <script type='text/javascript' src="/js/judgement/common.js"></script>
        <script type="text/javascript" src="/js/popover/tooltip.js"></script>
        <script type="text/javascript" src="/js/popover/popover.js"></script>
        
        

        <script type="text/javascript" src="/js/json2.js"></script>
        <script type="text/javascript" src="/js/annotation/annotator.min.js"></script>
        <script type="text/javascript" src="/js/annotation/annotator.permissions.min.js"></script>
        <script type="text/javascript" src="/js/annotation/annotator.store.min.js"></script>
        <script type="text/javascript" src="/js/annotation/annotator.tags.min.js"></script>
        
        






<script type="text/javascript">
        (function($) {
        	$("body").on("click", ".favorite-o", favorite_o); // 收藏
        	$("body").on("click", ".favorite", favorite);  // 取消收藏
        	
        	function favorite_o() {
        		var isAuthenticated = false;
                if (isAuthenticated) {
                    var name = "兖州市量子科技有限责任公司与孟凡英专利权权属纠纷二审民事判决书";
                    var type = "judgement";
                    var uri = "opendata.Judgement:c991df9fd78442ddba1e4f469f1f127c";
                    $.ajax({
                        type : "post",
                        url : "/service/rest/opendata.Favorite/collection/create",
                        dataType : "json",
                        data : {
                        	_csrf:"ec1ccefa-7511-4d3d-8b5d-fbc47bac7bea",
                        	name : name,
                            type : type,
                            uri : uri
                        },
                        success : function (data) {
                            if (data.code == 1) {
                                $(".favorite-o").removeClass("favorite-o").addClass("favorite");
                                $(".favorite").children("a").text("取消收藏");
                            }
                        }
                    });
                } else {
                    if (confirm("需要登录后才能收藏，现在登录？")) {
                        location = "/login.jsp?returnTo=%2Fjudgement%2Fc991df9fd78442ddba1e4f469f1f127c";
                    }
                }
        	}
            
        	function favorite() {
        		var isAuthenticated = false;
                if (isAuthenticated) {
                    var uri = "opendata.Judgement:c991df9fd78442ddba1e4f469f1f127c";
                    $.ajax({
                        type : "post",
                        url : "/service/rest/opendata.Favorite/collection/delete",
					dataType : "json",
					data : {
						_csrf:"ec1ccefa-7511-4d3d-8b5d-fbc47bac7bea",
						uri : uri
					},
					success : function(data) {
						if (data.code == 1) {
							$(".favorite").removeClass("favorite").addClass("favorite-o");
							$(".favorite-o").children("a").text("添加收藏");
						}
					}
				});
			}
		}

		var annotation_off = false;
		$("#annotationSwitch").click(function() {
			if (!annotation_off) {
				$(".annotator-hl").addClass("annotator-off").removeClass("annotator-hl");
				$(this).addClass("annotation-o").removeClass("annotation");
				$(this).children("a").text("显示批注");
				annotation_off = true;
			} else {
				$(".annotator-off").addClass("annotator-hl").removeClass("annotator-off");
				$(this).addClass("annotation").removeClass("annotation-o");
				$(this).children("a").text("隐藏批注");
				annotation_off = false;
			}
		});

		$("body").on("keydown", "#annotator-field-0", annotationFilter);
		function annotationFilter() {
			if ($(this).val().length > 140 && event.keyCode != 8 
					&& event.keyCode != 127 && event.keyCode != 46 
					&& event.keyCode != 37 && event.keyCode != 38 
					&& event.keyCode != 39 && event.keyCode != 40) {
				event.returnValue = false;
			}
		}

	})(jQuery);
</script>
        
            






<script type="text/javascript">
	(function($) {
		$("body").on("click", ".annotator-adder", authCheck);
		$("body").on("click", ".annotator-edit", authCheck);
        function authCheck() {
            var isAnonymousUser = true;
            if (isAnonymousUser) {
                $(".annotator-cancel").click();
                if (confirm("需要登录后才能使用该功能，现在登录？")) {
                    location = "/login.jsp?returnTo=%2Fjudgement%2Fc991df9fd78442ddba1e4f469f1f127c";
                }
                return false;
            }
        }
	})(jQuery);
	
	jQuery(function ($) {
	    if (typeof $.fn.annotator === 'function') {
	      $('#entry-cont').annotator().annotator('addPlugin', 'Tags').annotator('addPlugin', 'Store', {
	           prefix : '/annotation/',
	           annotationData : {
	               'docUri' : 'opendata.Judgement:c991df9fd78442ddba1e4f469f1f127c'
	           },
	           loadFromSearch : {
	               'docUri' : 'opendata.Judgement:c991df9fd78442ddba1e4f469f1f127c'
	           },
	           urls : {
	               create : 'create',
	               update : 'update/:id',
	               destroy : 'delete/:id',
	               search : 'list'
	           }
	       }).annotator('addPlugin', 'Permissions', {
	           user : {
	               id : '7cf5ef23f8fc409982064de7f251f42b',
	               username : 'anonymousUser'
	           },
	           userId : function (user) {
	               if (user && user.id) {
	                   return user.id;
	               }
	               return user;
	           },
	           userString : function (user) {
	             if (user && user.username) {
	                 return user.username;
	             }
	             return user;
	           },
	           permissions : {
	        	   'update' : ['7cf5ef23f8fc409982064de7f251f42b']
	           },
	           userAuthorize : function (action, annotation, user) {
	               var token, tokens;
	               if (annotation.permissions) {
	                   tokens = annotation.permissions[action] || [];
	                   if (tokens.length == 0) {
	                       return true;
	                   }
	                   for (var i = 0, len = tokens.length; i < len; i++) {
	                       token = tokens[i];
	                       if (token === this.userId(user)) {
	                           return true;
	                       }
	                   }
	                   return false;
	               } else if (annotation.user) {
	                   if (user) {
	                       return this.userId(user) === this.userId(annotation.user);
	                   } else {
	                       return false;
	                   }
	               }
	           }
	       });
	    }
	});
</script>
        
        
        <script type="text/javascript">
            (function($) {
                $('#up').click(function() {
                    $.ajax({
                        type : "get",
                        url : "/vote/c991df9fd78442ddba1e4f469f1f127c?side=Plaintiff&voter=anonymousUser",
                        dataType : "json",
                        success : function(data) {
                            var description = data.description;
                            var code = data.code;
                            if (code == 1) {
                                var up = data.result.plaintiffSucc;
                                var down = data.result.defendantSucc;
                                var percent = data.result.percent;
                                if (up > down && up > 0) {
                                    $('#result_percent').text("有" + percent + "%的人认为本案中法院支持了原告");
                                    $('#result_percent').show();
                                } else if (down > 0) {
                                    $('#result_percent').text("有" + percent + "%的人认为本案中法院支持了被告");
                                    $('#result_percent').show();
                                }
                                $('#up_num').text(up);
                                $('#down_num').text(down);
                            }
                            $('#result_p').text("");
                            $('#result').show();
                            $('#result_p').append(description);
                            setTimeout(function(){
                                $('#result_p').text("");
                                $('#result').hide();
                            }, 1000);
                        }
                    });
                });
                
                $('#down').click(function(){
                    $.ajax({
                        type : "get",
                        url : "/vote/c991df9fd78442ddba1e4f469f1f127c?side=Defendant&voter=anonymousUser",
                        dataType : "json",
                        success : function(data) {
                            var description = data.description;
                            var code = data.code;
                            if (code == 1) {
                                var up = data.result.plaintiffSucc;
                                var down = data.result.defendantSucc;
                                var percent = data.result.percent;
                                if (up > down && up > 0) {
                                    $('#result_percent').text("有" + percent + "%的人认为本案中法院支持了原告");
                                    $('#result_percent').show();
                                } else if (down > 0) {
                                    $('#result_percent').text("有" + percent + "%的人认为本案中法院支持了被告");
                                    $('#result_percent').show();
                                }
                                $('#up_num').text(up);
                                $('#down_num').text(down);
                            }
                            $('#result_p').text("");
                            $('#result').show();
                            $('#result_p').append(description);
                            setTimeout(function(){
                                $('#result_p').text("");
                                $('#result').hide();
                            }, 1000);
                        }
                    });
                });
                
                $(document).ready(function() {
                    var successPercent = "null";
                    if (successPercent && successPercent != "" && successPercent != "null" && successPercent != null) {
                        $('#result_percent').show();
                    } else {
                        $('#result_percent').hide();
                    }
                });
                
                $(function() { "use strict";
                    $('.popover-button-default').popover({
                        container: '#primary',
                        html: true,
                        animation: true
                    }).click(function(evt) {
                        evt.preventDefault();
                    });
                });

            })(jQuery);
            
            function popoverClose(e) {
            	var id = $(this).parent().attr("id");
                $("." + id).click();
             }
            
            function delTag(tagId) {
                if (tagId) {
                    $("#a_" + tagId).remove();
                }
            }
        </script>
        





    </div>
</body>
</html>


"""