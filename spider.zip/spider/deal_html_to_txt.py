from h import text
import html2text


def is_chinese(uchar):
    if '\u4e00' <= uchar<='\u9fff':
        return True
    else:
        return False
def tytle_end(data,num):
    key = 1
    i = 0
    while key:
        num2 = num + i
        zh = data[num2]
        key = is_chinese(zh)
        i = i + 1
    return num2
def get_tytle(html):
    num = html.find("<h2 class=\"entry-title\">") + len("<h2 class=\"entry-title\">")
    tytle = html[num:num+20]
    print(tytle)
    return tytle

def position_of_tytle(html):
    markdown = html2text.html2text(html)
    tytle = get_tytle(html)
    num_of_tytle = markdown.find(tytle)
    return num_of_tytle
def get_the_instrument(html):
    markdown = html2text.html2text(html)
    num_of_tytle = position_of_tytle(html)
    print(num_of_tytle,)
    num_the_end = markdown.find("书记员")
    if num_the_end==-1:
        num_the_end = markdown.find("记员")
    if num_the_end==-1:
        num_the_end = markdown.find("书记")
    if num_the_end==-1:
        num_the_end = markdown.find("审判长")+25
    if num_the_end==-1:
        num_the_end = markdown.find("审判员")+25
    print("start",num_of_tytle)
    print("end",num_the_end)
    instrument = markdown[num_of_tytle:num_the_end+10]
    return instrument

def to_txt(html,str):
    try:
        instrument = get_the_instrument(html)

        num = instrument.find("案号")
        txt_name = instrument[num:num+20]
        print(txt_name)
        txt_name = txt_name.replace("\n", '')
        txt_name = txt_name.replace('\r', '')

        if txt_name==''or txt_name=='![OpenL':
            txt_name = get_tytle(html)

        with open(str+"/"+txt_name+'.txt',"w+") as f:
            f.write(instrument)
            print(f.name)

        with open('name.txt','a+') as file:
            file.write(txt_name+'\n')

        return 1
    except:
        return -1

