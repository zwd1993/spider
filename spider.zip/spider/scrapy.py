# -*- coding: utf-8 -*-
import re
import os
import openpyxl
from openpyxl import Workbook
from openpyxl import load_workbook
def zlend(data,num):
    key = 1
    i = 0
    while key:
        num2 = num + i
        zh = data[num2]
        key = is_chinese(zh)
        i = i + 1
    print('num2',num2)
    return num2
def findall(str,fstr):
    num = str.find(fstr)
    lenn = len(fstr)
    list = []
    num1 = num
    while num !=-1:
        list.append(num1)
        str = str[num+lenn:]
        num = str.find(fstr)
        num1 = num1 +lenn +num
    return list
def is_chinese(uchar):
    if '\u4e00' <= uchar<='\u9fff':
        return False
    else:
        return True
def Test1(rootDir):
    wb = Workbook()
    data = wb.create_sheet('Data', index=1)
    list_dirs = os.walk(rootDir)
    n = 1
    for root, dirs, files in list_dirs:
        for f in files:
            print (os.path.join(root, f))
            with open(os.path.join(root, f),'r') as ftxt:
                if f == 'name.txt':
                    pass
                else:
                    txt = ''.join(ftxt.read())
                    listpatent = []

                    name = f
                    Court = txt[txt.find('* 法院')+7:txt[txt.find('* 法院')+4:].find('法院')+txt.find('* 法院')+6]
                    patentNm = findall(txt, 'ZL')
                    patentNm1 = findall(txt,'zl')
                    if patentNm != None:
                        for num  in patentNm:
                            end  =zlend(txt,num)
                            listpatent.append(txt[num:end])
                    if patentNm1 != None:
                        for num  in patentNm1:
                            end  =zlend(txt,num)
                            listpatent.append(txt[num:end])
                    search = re.search('2\d{11}.\d{1}',txt)
                    if search != None:
                        patentNm2 = search.span()
                        value = txt[patentNm2[0]:patentNm2[1]]
                        listpatent.append(value)
                    else:
                        patentNm2 = ''
                    Time = txt[txt.find("日期")+4:txt.find("日期")+14]
                    print('name',name)
                    print('fayuan',Court)
                    print('riqi',Time)
                    patent = ' '.join(listpatent)
                    print('zhaungli', patent)
                    print(patent)
                    data.cell(row=n, column=1).value = name
                    data.cell(row=n, column=2).value = Court
                    data.cell(row=n, column=3).value = patent
                    data.cell(row=n, column=4).value = Time
                    n = n +1
    wb.save('balances.xlsx')
    wb.close()

Test1('1')



