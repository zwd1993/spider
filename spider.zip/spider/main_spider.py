from fspider import *
from urllist import list
from deal_html_to_txt import  *


def main(url,cookie):

    for page in range(100):
        page = page+1
        url = url+"&page="+str(page)
        print(url)
        listid = spid(url,cookie)
        print(len(listid))
        if len(listid)==1:
            break
        else:
            for i in range(1,len(listid)):
                id = listid[i]
                urldata ="http://openlaw.cn/judgement/"+id
                html = get_data(urldata,cookie)
                print(html)
                while to_txt(html)==-1:
                    changeip()
                    cookie = get_cookie()
                    while cookie==-1:
                        changeip()
                        cookie = get_cookie()
                    html = get_data(urldata, cookie)
                # changeip()
                #cookie = get_cookie()
                print(cookie)





if __name__=="__main__":
    for num in list:
        # changeip()
        cookie = get_cookie()
        print(cookie)
        if cookie==-1:
            cookie = get_cookie()
        url = list[num]
        main(url,cookie)
