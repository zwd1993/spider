s = "_8aecfc257cc72dd429491e48bcbb935a"

s1 = s[2:4]
s2 = "n"
s3 = s[0:1]
s4 = "p"
s5 = s[4:8]
s6 = "e"
s7 = s[1:2]
s8 = s[16:]
s9 = s[8:16]
print(s1+s2+s3+s4+s5+s6+s7+s8+s9)

str = "a href=\"/judgement/56727fabc631470aab96cfd49e0a65d7\"a href=\"/judgement/56727fabc631470aab96cfd49e0a65d7\"a href=\"/judgement/56727fabc631470aab96cfd49e0a65d7\""
str2 ="a href=\"/judgement/"
def search(str,str2):
    list = []
    key =1
    i =0
    while key!=-1:
        key = str.find(str2,i,len(str))
        i = key+ len(str2)
        list.append(key)
        print(key)
    return list
list = search(str,str2)
def get_id(str,list):
    list2= []
    for i in list:
        if i ==-1:
            return list2
        list2.append(str[i+19:i+19+32])
list2 = get_id(str,list)
print(list2)


